﻿namespace WebAPI
{
    public static class AppSettings
    {
        public static string ConnectionString { get; set; }
        public static string Secret { get; set; }
    }
}
