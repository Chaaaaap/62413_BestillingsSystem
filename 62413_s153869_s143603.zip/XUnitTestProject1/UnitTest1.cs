using System;
using Xunit;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace XUnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
